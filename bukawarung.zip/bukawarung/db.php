<?php
$hostname = 'sql208.epizy.com';
$username = 'epiz_28817139';
$password = 'psZZk4KCSIu9ei2';
$dbname = 'epiz_28817139_db_bukawarung';

$conn = mysqli_connect($hostname, $username, $password, $dbname) or die ('Gagal terhubung ke database');
?>